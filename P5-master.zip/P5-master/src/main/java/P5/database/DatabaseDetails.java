package P5.database;

/*
 * Use this class to store your database credentials
 */
public class DatabaseDetails {

    /**
     * Username for the Database connection
     */
    final static protected String username = "hst_2020_20gr5401";
    /**
     * Password for the Database connection
     */
    final static protected String password = "ahdoodieseerahsoosha";
    /**
     * Host for the Database connection
     */
    // Der manglede "//" efter jdbc:mysql: og ";" skulle erstattes med ":"
    final static protected String host = "jdbc:mysql://db.course.hst.aau.dk:3306/hst_2020_20gr5401";

}
