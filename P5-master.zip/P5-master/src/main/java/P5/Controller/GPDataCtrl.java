package P5.Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.ScatterChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class GPDataCtrl extends DataCtrl {
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane Border;

    @FXML
    private Button closeECD;

    @FXML
    private Button showData3days;

    @FXML
    private ScatterChart<Double, Integer> rhrGraph;

    @FXML
    private Label firstname;

    @FXML
    private Label lastname;

    @FXML
    private Label cprNumber;

    @FXML
    private Button showData7days;

    @FXML
    private Button showData14days;

    @FXML
    void closeECD(ActionEvent event) {

    }

    @FXML
    void data14days(ActionEvent event) {

    }

    @FXML
    void data3days(ActionEvent event) {

    }

    @FXML
    void data7days(ActionEvent event) {

    }    


    @FXML
    void initialize() {
        
        assert Border != null : "fx:id=\"Border\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert closeECD != null : "fx:id=\"closeECD\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert showData3days != null : "fx:id=\"showData3days\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert rhrGraph != null : "fx:id=\"rhrGraph\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert firstname != null : "fx:id=\"firstname\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert lastname != null : "fx:id=\"lastname\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert cprNumber != null : "fx:id=\"cprNumber\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert showData7days != null : "fx:id=\"showData7days\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        assert showData14days != null : "fx:id=\"showData14days\" was not injected: check your FXML file 'GPLayoutView.fxml'.";
        
        // for at hente patient information fra databasen
        String newPatient = getPatientInfo();
        String[] splitPatient = newPatient.split(" ");
        String firstName = splitPatient[0];
        String lastName = splitPatient[1];
        String CPR = splitPatient[2]; 
        // for at opdatere information på interfacet 
        firstname.setText(firstName);
        lastname.setText(lastName);
        cprNumber.setText(CPR);

        // for at hente data til grafen fra databasen
        String[] RHRInfo = getRHRInfo();
        int[] RHR3Days = new int[30];
        double[] time_axis = getTimeInfo();

        // for at opdatere grafen på interfacet 
        XYChart.Series<Double,Integer> graph = new XYChart.Series<>();
            for (int i = 0; i < 30 ; i++){
                RHR3Days[i] = Integer.parseInt(RHRInfo[i]);
                graph.getData().add(new XYChart.Data<>(time_axis[i],RHR3Days[i]));
                rhrGraph.getData().add(graph);
                graph.setName("Resting Heart rate");
        } 
    }
}
