package P5.Controller;

import P5.Model.PMHandler;
import P5.Model.PatientHandler;
import P5.database.DatabaseManipulator;

public class DataCtrl {
    public static String getPatientInfo() {
        // Make a new personshandler
        PatientHandler ph = new PatientHandler();

        // Use the database manipulator to make a query
        DatabaseManipulator.executeQueryWithResultSet(ph);

        String personList = ph.getPersonList().toString();

        String nPatient = personList.replace("[", "");
        String newPatient = nPatient.replace("]", "");

        return newPatient;
    }

public static String[] getRHRInfo(){
    PMHandler pmh = new PMHandler();
        // Use the database manipulator to make a query
        DatabaseManipulator.executeQueryWithResultSet(pmh);
        String PMList = pmh.getPMList().toString();

        String RHRList = PMList.replace(" null", "");
        String RHRList1 = RHRList.replace("[", "");
        String RHRList2 = RHRList1.replace("]", "");
        String[] RHR_ny = RHRList2.split(", ");

        return RHR_ny;
}

    public static double[] getTimeInfo() {
        // Make a new personshandler
        PMHandler pmh = new PMHandler();
        
        // Use the database manipulator to make a query
        DatabaseManipulator.executeQueryWithResultSet(pmh);

        double[] time_axis = new double[]{0.0, -0.1, -0.2, -0.3, -0.4, -0.5, -0.6, -0.7, -0.8, -0.9, -1.0, -1.1, -1.2, -1.3, -1.4, -1.5, -1.6, -1.7, -1.8, -1.9, -2.0, -2.1, -2.2, -2.3, -2.4, -2.5, -2.6, -2.7, -2.8, -2.9};
        return time_axis;
    }
}
