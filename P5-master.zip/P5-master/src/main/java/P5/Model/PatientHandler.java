package P5.Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import P5.database.Queryable;

public class PatientHandler implements Queryable {
    //ArrayList with PersonModel objects
    private ArrayList<PatientModel> personList = new ArrayList<>();

    ///Method for adding a person to the list of personsModel.
    public void addPersonToList(PatientModel p) {
        this.personList.add(p);
    }

    //Get the list of all persons (returns The list with personModel objects
    public ArrayList<PatientModel> getPersonList() {
        return this.personList;
    }

    //Method for processing the ResultSet.
    @Override
    public void processResultSet(ResultSet rs) throws SQLException {
       
        while(rs.next()){
        this.addPersonToList(new PatientModel(rs.getString("firstName"), rs.getString("lastName"), rs.getString("CPR")));
    }
}
        
    //Return SQL Query as String for selecting data in the Database
   @Override
    public String returnSqlQuery() {
        String sqlStatement = "SELECT * from Patient WHERE CPR = 2706925598";
        return sqlStatement;
    }
}


