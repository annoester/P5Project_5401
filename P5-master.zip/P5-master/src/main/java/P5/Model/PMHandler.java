package P5.Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import P5.database.Queryable;


public class PMHandler implements Queryable {

    // ArrayList with PhysiologicalMetricModel objects
    private ArrayList<PhysiologicalMetricModel> PMList = new ArrayList<>();

    // Method for adding a PhysiologicalMetricModel to the list of PhysiologicalMetricModels
    public void addPMToList(PhysiologicalMetricModel pm) {
        this.PMList.add(pm);
    }

    // Get the list of all persons (return the list with PhysiologicalMetricModel objects)
    public ArrayList<PhysiologicalMetricModel> getPMList() {
        return this.PMList;
    }

    // Method for processing the ResultSet. This will add PhysiologicalMetricModel-objects to the list
    @Override
    public void processResultSet(ResultSet rs) throws SQLException {
       
        while(rs.next()){
        this.addPMToList(new PhysiologicalMetricModel(rs.getInt("RHR")));
        }
    }
        
    // Return SQL Query as String for selecting data in the Database
   @Override
    public String returnSqlQuery() {
        String sqlStatement = "SELECT RHR from PhysiologicalMetrics WHERE CPR_fk = 2706925598 AND PMID < 35 ORDER BY PMID DESC";
        return sqlStatement;
    }
}

