package P5.Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import P5.database.Queryable;

public class PhysiologicalMetricModel implements Queryable{
     
    // attributes
     private int RHR;
     private int currentRHRBaseline;
     private String timeStamp;
     private boolean outlier;

     //constructors
     public PhysiologicalMetricModel(int RHR){
         this.RHR = RHR;
         // mangler de resterende attributter 
     }
     
    //methods
    @Override
    public String toString() {
        return this.RHR + " " + this.timeStamp;}

    @Override
    public void processResultSet(ResultSet rs) throws SQLException {
        rs.next();
        this.RHR = rs.getInt("RHR");
        this.timeStamp = rs.getString("timeOfMeasurement");
    }

    @Override
    public String returnSqlQuery() {
        String sqlQuery = " ";
        return sqlQuery;
    }

     public int getRHR(){
         //metode der skal returnere RHR værdier 
         return RHR;
     }

     public int getCurrentBaseline(){
         //metode der skal returnere baseline for det pågældende RHR data
         return currentRHRBaseline;
     }

     public String getTimestamp(){
         //metode der skal returnere timestamps for RHR dataet
         return timeStamp;
     }

     public boolean getBooleanOutlier(){
         //metode der skal returnere om der er en outlier eller ej 
        return outlier;
     }

     public boolean checkForOutlier(int RHR, int currentRHRBaseline, String timeStamp){
         //algoritmen til at detektere outlier i RHR dataet 
         return outlier;
     }

     public void setOutlier(){
         //metode til at ændre attributten, hvis der er detekteret en outlier
     }

}