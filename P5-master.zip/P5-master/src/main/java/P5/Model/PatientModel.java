package P5.Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import P5.database.Queryable;
public class PatientModel implements Queryable {
    // attributes
    private String firstName;
    private String lastName;
    private String CPR;
    private boolean consent;
    private boolean notification;

    // constructor
   public PatientModel(String firstName, String lastName, String CPR) {
        this.firstName = firstName; 
        this.lastName = lastName; 
        this.CPR = CPR;
        // this.consent = consent; 
        // this.notification = notification;
    }

    // methods
	// Return a String with first name, last name and CPR 
    @Override
    public String toString() {
        return this.firstName + " " + this.lastName + " " + this.CPR;
    }

    //Method that sets the first name, last name and CPR of the person based on the resultset from the database
    @Override
    public void processResultSet(ResultSet rs) throws SQLException {
        rs.next();
        this.firstName = rs.getString("firstName");
        this.lastName = rs.getString("lastName");
        this.CPR = rs.getString("CPR");
    }

    @Override
    public String returnSqlQuery() {
        String sqlQuery = " ";
        return sqlQuery;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCPR() {
        return CPR;
    }

    public void setConsent(boolean consent) {
        this.consent = consent;
    }

    public boolean getConsent() {
        return consent;
    }

    public void setNotification(boolean notification) {
        this.notification = notification;
    }

    public boolean getNotification() {
        return notification;
    }
}